class Vehicle {
  constructor(
    color,
    trim,
    wheels,
    interior,
    enhancedAutoPilot,
    fullSelfDrivingCapability
  ) {
    this.color = color;
    this.trim = trim;
    this.wheels = wheels;
    this.interior = interior;
    this.enhancedAutoPilot = enhancedAutoPilot;
    this.fullSelfDrivingCapability = fullSelfDrivingCapability;
    this.numberOfWheels = null;
    this.numberOfDoors = null;
  }

  details() {
    const enhancedAutoPilotStatus = this.enhancedAutoPilot
      ? "enabled"
      : "disabled";
    const fullSelfDrivingCapabilityStatus = this.fullSelfDrivingCapability
      ? "enabled"
      : "disabled";
    console.log(
      `This vehicle is ${this.color} with ${this.trim} trim, ${this.wheels} wheels, and ${this.interior} interior. This vehicle has Enhanced Auto Pilot ${enhancedAutoPilotStatus} and Full Self Driving Capability ${fullSelfDrivingCapabilityStatus}.`
    );
  }
}

class ModelS extends Vehicle {
  constructor(
    color,
    trim,
    wheels,
    interior,
    enhancedAutoPilot,
    fullSelfDrivingCapability,
    topSpeed
  ) {
    super(
      color,
      trim,
      wheels,
      interior,
      enhancedAutoPilot,
      fullSelfDrivingCapability
    );
    this._topSpeed = topSpeed;
  }

  get topSpeed() {
    return this._topSpeed;
  }

  set topSpeed(speed) {
    if (this.trim.toLowerCase() === "plaid") {
      this._topSpeed = 200;
    } else if (this.trim.toLowerCase() === "standard") {
      this._topSpeed = 149;
    } else {
      console.log("Invalid trim option. Please set top speed manually.");
    }
  }

  howFast() {
    console.log(`This Model S has a top speed of ${this.topSpeed} mph.`);
  }
}

const modelS = new ModelS(
  "Dark Silver",
  "Plaid",
  '21" Performance',
  "Gray Leather",
  true,
  true,
  null
);
modelS.topSpeed = modelS.topSpeed;
modelS.details();
modelS.howFast();
