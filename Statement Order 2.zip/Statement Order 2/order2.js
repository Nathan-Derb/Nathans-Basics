console.log("<<< Starting >>>"); // 1st Prints "<<< Starting >>>" executed first, its outside of any asynchronus functions
const p2 = new Promise((resolve, reject) => {
  console.log("First"); // 2nd Prints "First" it will be executed synchronously as part of the promise's executor function when the promise is instantiated
  console.log("Last");  // 3rd Prints "Last"
});

p2.then((res) => {
  console.log(res); // Log statement 4: This callback will never be called as p2 is not resolved/rejected
});

console.log("<<< Ending >>>"); // 4th Prints "<<< Ending >>>" - executed fourth and last
