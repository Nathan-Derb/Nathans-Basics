function fetchPost(author, postText) {
  const url = 'https://jsonplaceholder.typicode.com/posts';
  const payload = {
    author: author,
    postText: postText
  };

  return fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  })
    .then(response => {
      if (response.ok) {
        return response.json()
          .then(data => data.id);
      } else {
        throw new Error(`Error creating post: ${response.status} ${response.statusText}`);
      }
    })
    .catch(error => {
      console.error(error);
    });
}


async function asyncAwaitPost(author, postText) {
  const url = 'https://jsonplaceholder.typicode.com/posts';
  const payload = {
    author: author,
    postText: postText
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      const data = await response.json();
      return data.id;
    } else {
      throw new Error(`Error creating post: ${response.status} ${response.statusText}`);
    }
   } catch (error) {
    console.error(error);
  }
}

const author = 'Mr.Crisp';
const postText = 'Potato Chip!';
asyncAwaitPost(author, postText)
  .then(createdPostId => {
    if (createdPostId) {
      console.log(`Success! Created post with ID: ${createdPostId}`);
    }
  });