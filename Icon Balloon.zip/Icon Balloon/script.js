const icon = document.getElementById('explosion-icon');
const body = document.body;

let size = 100;

document.addEventListener('keydown', (event) => {
  if (event.key === 'ArrowUp') {
    size *= 1.1;
    icon.style.fontSize = `${size}px`;
    icon.classList.remove('explosion');
    icon.classList.add('animated');
    body.classList.remove('body-explosion');
  } else if (event.key === 'ArrowDown') {
    size *= 0.9;
    icon.style.fontSize = `${size}px`;
    icon.classList.remove('explosion');
    body.classList.remove('body-explosion');
  }
  
  if (size > 200) {
    icon.classList.remove('fa-bomb');
    icon.classList.add('fa-explosion');
    icon.classList.add('explosion');
    body.classList.add('body-explosion');
    icon.classList.add('shake');
  } else {
    icon.classList.remove('fa-explosion');
    icon.classList.add('fa-bomb');
    icon.classList.remove('shake');
  }
});