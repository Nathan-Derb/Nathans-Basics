const catalog = [
  {
    title: "The Inner Citadel",
    author: "Pierre Hadot",
    published: 1998,
    copies: 2,
    categories: ["Philosophy", "Greek and Roman History"],
  },
  {
    title: "Thinking, Fast and Slow",
    author: "Daniel Kahneman",
    published: 2011,
    copies: 22,
    categories: ["Psychology", "Decision Making"],
  },
  {
    title: "The Tao of Chess",
    author: "Peter Kurzdorfer",
    published: 2004,
    copies: 12,
    categories: ["Taoist Philosophy", "Chess"],
  },
];

// Use the .push() method here
catalog.push({
 title: "Pub mix",
 author: 'Savory utz',
 pushblished: 2023,
 copies: 1,
 categories: ["My snack", "cheesy"],
})

// Use the .pop() method here
const results = catalog.pop();
console.log(results);
console.log(catalog);

// Use the .shift() method here
const results2 = catalog.shift();
console.log(results2);
console.log(catalog);
// Use the .unshift() method here
catalog.unshift("pretzel");
console.log(catalog);
