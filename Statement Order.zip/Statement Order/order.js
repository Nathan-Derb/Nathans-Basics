console.log("<<< Starting >>>"); // First log statement, executed immediately

setTimeout(() => {
	console.log('Timeout Called'); // Fourth log statement, queued in the event loop, executed after the synchronous promise and << Ending >>
}, 0);

const p1 = new Promise((resolve, reject) => {
  console.log("First"); // Second log statement, executed immediately
  resolve("Second"); // Promise is resolved with "Second" value, but the `then` handler is queued in the event loop
  console.log("Last"); // Third log statement, executed immediately
});

p1.then((res) => {
  console.log(res); // Fifth log statement, queued in the event loop, executed after "Timeout Called"
});

console.log("<<< Ending >>>"); // Sixth log statement, executed immediately

//I had to run the code to figure it out