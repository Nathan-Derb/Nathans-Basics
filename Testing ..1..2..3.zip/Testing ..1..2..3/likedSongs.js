function getLikedSongs(songs) {
  return songs.filter(song => song.liked);
}
module.exports = getLikedSongs;