const getLikedSongs = require('./likedSongs');

describe('getLikedSongs function', () => {
  it('returns an array of liked songs', () => {
    const songs = [
      { title: 'In the Air Tonight', artist: 'Phil Collins', liked: true },
      { title: 'Into the Night', artist: 'Santana', liked: false },
      { title: 'The Sound of Silence', artist: 'Disturbed', liked: true },
      { title: 'Broken', artist: 'Seether', liked: false }
    ];

    expect(getLikedSongs(songs)).toEqual([
      { title: 'In the Air Tonight', artist: 'Phil Collins', liked: true },
      { title: 'The Sound of Silence', artist: 'Disturbed', liked: true }
    ]);
  });
});
