const myObj = {
  a: {
    b: {
      c: [
        {
          d: {
            e: {
              f: [
                {
                  g: {
                    h: {
                      i: [
                        {
                          j: {
                            k: {
                              name: "Deeply Nested Object Property"
                            }
                          }
                        }
                      ]
                    }
                  }
                }
              ]
            }
          }
        }
      ]
    }
  }
};
const nestedNelly = myObj.a.b.c[0].d.e.f[0].g.h.i[0].j.k.name;
console.log(nestedNelly);