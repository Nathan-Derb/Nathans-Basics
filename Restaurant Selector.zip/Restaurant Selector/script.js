let restaurants = [
  'Chick fil-a',
  'Subway',
  'Taco Bell',
  'Panera Bread',
  'Wendys',
  'KFC'
];

function createRestaurantElement(name) {
  let li = document.createElement('li');
  li.id = name.toLowerCase().replace(/ /g, '-');
  li.textContent = name;
  return li;
}

function displayRestaurants() {
  let restaurantList = document.getElementById('restaurantList');
  restaurantList.innerHTML = '';
  restaurants.forEach(name => {
    let li = createRestaurantElement(name);
    restaurantList.appendChild(li);
    li.addEventListener('click', () => {
      li.style.color = 'green';
    });
  });
}

function addRestaurant() {
  let newRestaurantInput = document.getElementById('newRestaurant');
  let newRestaurantName = newRestaurantInput.value.trim();
  if (newRestaurantName !== '') {
    restaurants.push(newRestaurantName);
    let li = createRestaurantElement(newRestaurantName);
    document.getElementById('restaurantList').appendChild(li);
    newRestaurantInput.value = '';
    li.addEventListener('click', () => {
      li.style.color = 'green';
    });
  }
}

function selectRandomRestaurant() {
  let randomIndex = Math.floor(Math.random() * restaurants.length);
  let selectedRestaurant = restaurants[randomIndex];
  let selectedLi = document.getElementById(selectedRestaurant.toLowerCase().replace(/ /g, '-'));
  
  let liElements = document.getElementsByTagName('li');
  for (let i = 0; i < liElements.length; i++) {
    liElements[i].classList.remove('selected');
    liElements[i].style.fontSize = '1rem';
  }
  
  selectedLi.classList.add('selected');
  
  selectedLi.style.fontSize = '1.2rem';
}

document.getElementById('addRestaurant').addEventListener('click', addRestaurant);

document.getElementById('selectRestaurant').addEventListener('click', () => {
  displayRestaurants();
  selectRandomRestaurant();
});

displayRestaurants();


