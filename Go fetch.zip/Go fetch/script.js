 function fetchDogPicture() {
      fetch('https://dog.ceo/api/breeds/image/random')
        .then(response => response.json())
        .then(data => {
          let img = new Image();
          img.src = data.message;
          img.alt = 'Dog Image';
          document.getElementById('dogImageContainer').innerHTML = '';
          document.getElementById('dogImageContainer').appendChild(img);
        })
        .catch(error => console.error(error));
    }