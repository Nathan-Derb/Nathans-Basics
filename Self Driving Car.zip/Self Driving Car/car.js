let car = "KodeCar";
const night = "dark";
let weather = "rainy";
let speed = 0;

if (night === "dark") {
  console.log("lights on");
}
if (weather === "rainy") {
  console.log("wipers on");
}
if (speed > 0) {
  console.log("fasten seatbelt");
}
