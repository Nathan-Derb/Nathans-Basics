const squared = async (value) => {
  return new Promise((resolve, reject) => {
    if (Number.isFinite(value)) {
      resolve(value * 2);
    } else {
      reject("The value parameter is not a valid number");
    }
  });
};

(async () => {
  let inpNum = 1;
  try {
    for (let i = 0; i < 10; i++) { // run code 10x = Result for input value 512: 1024
      const result = await squared(inpNum);
      console.log(`Result for input value ${inpNum}: ${result}`);
      inpNum = result;
    }
  } catch (error) {
    console.error(error);
  }
})();
