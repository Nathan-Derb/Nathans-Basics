const books = [
  "The Inner Citadel",
  "Thinking, Fast and Slow",
  "The Tao of Chess",
];

// Your code below this line
const target = "The Tao of Chess";
const results = books.includes(target);
console.log(`Is ${target} in the book: ${results}`);
