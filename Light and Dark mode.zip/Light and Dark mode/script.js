const toggleBtn = document.getElementById('toggle-btn');
const bodyEl = document.body;

toggleBtn.addEventListener('click', function() {
  bodyEl.classList.toggle('dark-mode');
  
  if (bodyEl.classList.contains('dark-mode')) {
    toggleBtn.textContent = 'Switch to Light Mode';
    localStorage.setItem('mode', 'dark');
  } else {
    toggleBtn.textContent = 'Switch to Dark Mode';
    localStorage.setItem('mode', 'light');
  }
});

const mode = localStorage.getItem('mode');
if (mode === 'dark') {
  bodyEl.classList.add('dark-mode');
  toggleBtn.textContent = 'Switch to Light Mode';
}