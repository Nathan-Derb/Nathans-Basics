console.log("<<< Starting >>>"); // 1st outside of the promise and microtask queue so its executed immediately

function run(value) { //This defines a function that returns a promise.
  return new Promise((resolve, reject) => { //This line sets up a new promise to handle asynchronous operations.
    if (value) resolve("Win!"); //Resolves with 'Win!' if truthy.
    else reject("Lose!"); //Otherwise rejects with 'Lose!' if falsy.
  });
}

let p3 = run(true); // This creates a new promise p3, which resolves with 'Win!'.

p3.then((res) => { //The resolved value p3, which is 'Win!'.
  console.log(res); // 3rd executed showing 'Win!' from the p3 promise.
  return run(false); // This returns a new promise which is rejected with 'Lose!'.
}).catch((res) => {
  console.log(res); // 4th prints 'Lose!' from previous rejected promise, otherwise 'Error!' prints.
  return "Error!"; // Returns a non-promise value 'Error!' as stated above ^.
})
.then((res) => {
  console.log(res); // 5th console executed, the previouse promise had a true value.
  return run(true); // This returns the new promise which is resolved with 'Win!'.
})
.then((res) => {
  console.log(res); // 6th prints 'Win!' becuase the 'run(true)' promise is resolved with the value 'true'.
  return run(false); // Returns a new promise that is  rejected with 'Lose!'.
})
.then((res) => {
  console.log(res); //Shows "uncaught (in promise)Lose!" and im not sure why. I think its because theres a rejected promise not being cuaght by the .catch block.
  return run(true); // This returns the new promise which gets resolved with 'Win!'.
});

console.log("<<< Ending >>>"); // 2nd console log ran beofore the promises due to microtask queue.