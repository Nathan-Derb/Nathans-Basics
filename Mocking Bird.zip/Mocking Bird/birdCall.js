class BirdCall {
  constructor() {}

  getSound(birdType) {
    switch (birdType) {
      case 'robin':
        return 'tweet tweet';
      case 'sparrow':
        return 'chirp chirp';
      case 'crow':
        return 'caw caw';
      default:
        throw new Error(`Invalid bird type: ${birdType}`);
    }
  }

  generateBirdCall(birdType) {
    const sound = this.getSound(birdType);
    return `A ${birdType} says ${sound}.`;
  }
}

module.exports = BirdCall;
