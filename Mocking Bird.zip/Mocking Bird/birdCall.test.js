const BirdCall = require('./birdCall');

describe('BirdCall class', () => {
  describe('getSound method', () => {
    it('should return the correct sound for a robin', () => {
      const birdCall = new BirdCall();
      const sound = birdCall.getSound('robin');
      expect(sound).toBe('tweet tweet');
    });

    it('should return the correct sound for a sparrow', () => {
      const birdCall = new BirdCall();
      const sound = birdCall.getSound('sparrow');
      expect(sound).toBe('chirp chirp');
    });

    it('should return the correct sound for a crow', () => {
      const birdCall = new BirdCall();
      const sound = birdCall.getSound('crow');
      expect(sound).toBe('caw caw');
    });
  });
});
