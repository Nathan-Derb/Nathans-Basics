function WellsFargoEverydayChecking(name, balance) {
  this.name = name;
  this.balance = balance;
}

WellsFargoEverydayChecking.prototype.addMoney = function (value) {
  this.balance += value;
};

WellsFargoEverydayChecking.prototype.minusMoney = function (value) {
  this.balance -= value;
};

WellsFargoEverydayChecking.prototype.showBalance = function () {
  console.log(this.balance);
  return this.balance;
};

function WellsFargoEverydayCheckingPlus(name, balance) {
  WellsFargoEverydayChecking.call(this, name, balance); 
}

WellsFargoEverydayCheckingPlus.prototype = Object.create(WellsFargoEverydayChecking.prototype);
WellsFargoEverydayCheckingPlus.prototype.constructor = WellsFargoEverydayCheckingPlus;

WellsFargoEverydayCheckingPlus.prototype.minusMoney = function (value) {
  const originalBalance = this.balance;
  this.balance -= value;
  if (this.balance < 0) {
    this.balance -= 5.0;
    console.log("An overdraft fee has been applied to your account");
  }
  return originalBalance - this.balance; // Return the actual amount deducted
};

const account = new WellsFargoEverydayCheckingPlus("John Smith", 0);

const deductedAmount = account.minusMoney(20);
console.log(`$${deductedAmount} has been deducted from your account.`);

account.addMoney(100);

account.showBalance();
