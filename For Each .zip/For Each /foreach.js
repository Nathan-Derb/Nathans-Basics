const catalog = [
  {
    title: "The Inner Citadel",
    author: "Pierre Hadot",
    published: 1998,
    copies: 2,
    categories: ["Philosophy", "Greek and Roman History"],
  },
  {
    title: "Thinking, Fast and Slow",
    author: "Daniel Kahneman",
    published: 2011,
    copies: 22,
    categories: ["Psychology", "Decision Making"],
  },
  {
    title: "The Tao of Chess",
    author: "Peter Kurzdorfer",
    published: 2004,
    copies: 12,
    categories: ["Taoist Philosophy", "Chess"],
  },
];

// Your code below this line
catalog.forEach((element) => {
  console.log(`${element.title}: ${element.author}`);
  console.log(`CATEGORIES: ${element.categories.join(", ")}`);
});
