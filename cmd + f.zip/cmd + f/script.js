const searchInput = document.getElementById("search-input");
const text = document.getElementsByClassName("text");
const noMatch = document.getElementById("no-match");

let timeoutId;

function debounce(func, delay) {
  clearTimeout(timeoutId);
  timeoutId = setTimeout(func, delay);
}

function search() {
  const searchTerm = searchInput.value.trim();
  if (searchTerm) {
    const regex = new RegExp(`\\b${searchTerm}\\b(?![^<]*>)`, 'g');
    let matchFound = false;
    for (let i = 0; i < text.length; i++) {
      const matches = text[i].innerHTML.match(regex);
      if (matches) {
        text[i].innerHTML = text[i].innerHTML.replace(
          regex,
          `<span class="highlight">$&</span>`
        );
        matchFound = true;
      } else {
        text[i].innerHTML = text[i].innerHTML.replace(
          /<span class="highlight">([^<]*)<\/span>/g,
          "$1"
        );
      }
    }
    if (matchFound) {
      noMatch.style.display = "none";
    } else {
      noMatch.style.display = "block";
    }
  } else {
    for (let i = 0; i < text.length; i++) {
      text[i].innerHTML = text[i].innerHTML.replace(
        /<span class="highlight">(.*?)<\/span>/g,
        "$1"
      );
    }
    noMatch.style.display = "none";
  }
}

searchInput.addEventListener("input", () => {
  debounce(() => {
    search();
  }, 700);
});
