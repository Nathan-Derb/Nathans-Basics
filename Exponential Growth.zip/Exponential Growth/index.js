let exceptionalgrowth = (a, b) => a * b;
document.getElementById("test").innerHTML = exceptionalgrowth(2, 5);

function exceptionalgrowth(base, power) {
  let result = 1;
  for (let count = 0; count < power; count++) {
    result *= base;
  }
  return result;
}

console.log(exceptionalgrowth(3, 4));
